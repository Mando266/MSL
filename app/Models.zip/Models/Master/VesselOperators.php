<?php

namespace App\Models\Master;

use Illuminate\Database\Eloquent\Model;

class VesselOperators extends Model
{
    protected $table = 'vessels_operator';
    protected $guarded = [];
    
}
