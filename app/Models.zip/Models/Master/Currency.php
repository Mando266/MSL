<?php

namespace App\Models\Master;

use Illuminate\Database\Eloquent\Model;

class Currency extends Model
{
    protected $table = 'currency';
    protected $guarded = [];
}
