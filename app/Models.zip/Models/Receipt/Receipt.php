<?php

namespace App\Models\Receipt;

use Illuminate\Database\Eloquent\Model;

class Receipt extends Model
{
    //
}
