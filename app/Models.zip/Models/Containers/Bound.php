<?php

namespace App\Models\Containers;

use Illuminate\Database\Eloquent\Model;

class Bound extends Model
{
    protected $table = 'bound';
    protected $guarded = [];
}
