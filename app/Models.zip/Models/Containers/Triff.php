<?php

namespace App\Models\Containers;

use Illuminate\Database\Eloquent\Model;

class Triff extends Model
{
    protected $table = 'triff_kind';
    protected $guarded = [];
}
