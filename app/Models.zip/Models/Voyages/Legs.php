<?php

namespace App\Models\Voyages;

use Illuminate\Database\Eloquent\Model;

class Legs extends Model
{
    protected $table = 'legs';
    protected $guarded = [];
}
