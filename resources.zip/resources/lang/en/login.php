<?php

return array (
  'email' => 'Email',
  'forget_password' => 'Forget Password?',
  'keep_me_login' => 'Keep me login',
  'login' => 'Login',
  'login_to' => 'Login in to',
  'password' => 'Password',
  'password_confirmation' => 'Confirm Password',
  'password_updated' => 'Password updated successfully',
  'sign_out' => 'Sign out',
  'user_name' => 'User name',
);
