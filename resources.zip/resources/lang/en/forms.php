<?php

return array (
  'cancel' => 'Cancel',
  'create' => 'Create',
  'create_new' => '',
  'edit' => 'Edit',
  'search' => 'Search ...',
  'select' => 'Select ...',
  'update' => 'Update',
);
