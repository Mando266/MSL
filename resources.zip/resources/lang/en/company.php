<?php

return array (
  'address' => 'Address',
  'city' => 'City',
  'country' => 'Country',
  'create_new' => 'New Company',
  'created' => 'Company Created Successfully',
  'currencies' => 'Currencies',
  'email' => 'E-mail',
  'name' => 'Name',
  'phone' => 'Phone',
  'updated' => 'Company Updated Successfully',
  'main_currency'=>'Main Currency'
);
