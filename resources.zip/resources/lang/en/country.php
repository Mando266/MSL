<?php

return array (
  'create_new' => 'New Country',
  'created' => 'Country Created Successfully',
  'name' => 'Name',
  'prefix' => 'Code',
  'updated' => 'Country Updated Successfully',
);
