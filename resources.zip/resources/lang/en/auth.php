<?php

return array (
  'failed' => 'These credentials do not match our records.',
  'inactive_failed' => 'This user is disabled',
  'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',
);
