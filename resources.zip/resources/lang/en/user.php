<?php

return array (
  'avatar' => 'Avatar',
  'companies' => 'Companies',
  'company' => 'Company',
  'create_new' => 'New User',
  'created' => 'User Created Successfully',
  'email' => 'Email',
  'employee_no' => 'Employee No',
  'full_name' => 'Full Name',
  'market_segments' => 'Market Segments',
  'role' => 'Role',
  'status' => 'Status',
  'updated' => 'User Updated Successfully',
  'user_name' => 'User Name',
);
