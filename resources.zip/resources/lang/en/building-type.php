<?php

return array (
  'create_new' => 'Create new Bulding Type',
  'name' => 'Building Type Name',
  'show' => 'Building Type Data',
  'created' => 'Building Type Created Successfully',
  'updated' => 'Building Type Updated Successfully',
  'deleted' => 'Building Type Deleted Successfully',
);
