<?php

return array (
  'create_new_role' => 'New Role',
  'created' => 'Role Created Successfully',
  'edit_role' => 'Edit Role',
  'name' => 'Role Name',
  'permission_actions' => 'Permission Actions',
  'permission_count' => 'Permissions Count',
  'permission_name' => 'Permission Name',
  'role_permissions' => 'Role Permissions',
  'updated' => 'Role Updated Successfully',
  'users_count' => 'Users Count',
);
