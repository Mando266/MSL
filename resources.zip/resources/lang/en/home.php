<?php

return array (
  'my_profile' => 'My profile',
  'no_data_found' => 'No Data Found',
  'reset_password' => 'Reset Password',
);
