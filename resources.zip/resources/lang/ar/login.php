<?php

return array (
  'email' => 'الايميل',
);
